import os
import socket
import sys
from datetime import datetime

from PIL import ImageGrab
from pynput import mouse


def get_host_ip():
    """
    查询本机ip地址
    :return: ip
    """
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('8.8.8.8', 80))
        ip = s.getsockname()[0]
    finally:
        s.close()
    return ip

root = os.path.dirname('./')
print(f'===> 1. Your Ip: {get_host_ip()}')

print(str(datetime.now())[:-10])
currPath = str(datetime.now())[:-10].replace(' ', '_').replace(':', '_').replace('-', '_')
com_name = input("===> 2. Input <Current Company Name>(or Default: pic):  ") or "pic"

# 请设置保存的文件夹，并将其设置为共享文件夹
currPath = os.path.join(root,currPath[0:10]+ '_'+ com_name + '/')
print(f'===> 3. currPath: {currPath}')
if not os.path.exists(currPath):
    os.mkdir(currPath)

cnt = 0
def on_click(x, y, button, pressed):
    if pressed and button == button.right:
        # print(x, y, button, pressed)
        global cnt
        im = ImageGrab.grab((0, 0, 1920, 1080))
        #后两个参数根据屏幕大小自己调整
        name = f'{cnt}_{datetime.now().minute}-{datetime.now().second}.png'
        print(name)
        im.save(f'{currPath}/{name}')
        cnt += 1

    if not pressed:
        return False

print(f'===> 4. Starting & Good Luck ...')
while True:
    with mouse.Listener(on_click = on_click) as listener:
        listener.join()
