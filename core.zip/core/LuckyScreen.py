# -*- coding:utf-8 -*-
import os
import tkinter as tk
import tkinter.messagebox as messagebox
from datetime import datetime
from tkinter import *

from PIL import ImageGrab
from pynput import mouse

import socket

def get_host_ip():
    """
    查询本机ip地址
    :return: ip
    """
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('8.8.8.8', 80))
        ip = s.getsockname()[0]
    finally:
        s.close()

    return ip


class Application(Frame):   #从Frame派生出Application类，它是所有widget的父容器
    def __init__(self,master = None):   #master即是窗口管理器，用于管理窗口部件，如按钮标签等，顶级窗口master是None，即自己管理自己
        Frame.__init__(self,master)
        self.pack()                     #将widget加入到父容器中并实现布局
        self.str = StringVar()  #保存为一个string类型的变量
        self.str.set('---<Printing>---')        #设置初始值
        self.cnt = 1
        self.createWidgets()
        self.isStart = True

        self.root = os.path.dirname(os.path.realpath(__file__))
        self.str.set(self.root)        #设置初始值
        self.currPath = str(datetime.now())[:-10].replace(' ', '_').replace(':', '_').replace('-', '_')
        self.cnt = 1

    def createWidgets(self):
        self.InputLabel = Label(self,text = 'Input <Current Company Name>',font = ("Times",14,'bold'), width = 40,height = 2)#创建一个标签显示内容到窗口
        self.InputLabel.pack()

        self.input = Entry(self,font = ("Times",14), fg = "blue")#创建一个输入框，以输入内容
        self.input.pack()

        self.PrintLabel = Label(self, textvariable = self.str, font = ("Times",12), fg = "blue" ,bg='pink', width = 40, height = 1)#创建一个标签显示内容到窗口
        self.PrintLabel.pack()

        self.RunButton = Button(self,text = 'Run',command = self.run, font = ("Times",12), foreground = 'blue', background = 'green', width  = 5,height = 1)#创建一个run按钮，点击调用run方法
        self.RunButton.pack(anchor='s',side=LEFT, expand=True)
        self.StopButton = Button(self,text = 'Pause',command = self.stop, font = ("Times",12), foreground  = 'blue', background = 'Orange',width  = 5, height = 1)#创建一个Stop按钮，实现点击即退出窗口
        self.StopButton.pack(anchor='s',side=LEFT, expand=True)
        self.StopButton.config(state=DISABLED)

        self.RecoverButton = Button(self,text = 'Recover',command = self.recover, font = ("Times",12), foreground  = 'blue', background = 'Orange',width  = 5, height = 1)#创建一个Recover按钮，实现点击即continue
        self.RecoverButton.pack(anchor='s',side=LEFT, expand=True)
        self.RecoverButton.config(state=DISABLED)

        self.quitButton = Button(self,text = 'Quit',command = self.quit, font = ("Times",12), foreground = 'blue', background = 'red',width  = 5,height = 1)#创建一个Quit按钮，实现点击即退出窗口
        self.quitButton.pack(anchor='s',side=LEFT, expand=True)




    def on_click(self, x, y, button, pressed):
        if pressed and button == button.right:
            # print(x, y, button, pressed)
            #后两个参数根据屏幕大小自己调整
            im = ImageGrab.grab((0, 0, 1920, 1080))
            print(self.name)
            im.save(f'{self.currPath}/{self.name}')
            self.cnt += 1
        if not pressed:
            return False


    def stop(self):
        self.isStart = False
        self.InputLabel.config(state=NORMAL)
        self.RunButton.config(state=NORMAL)
        self.RecoverButton.config(state=NORMAL)
        self.quitButton.config(state=NORMAL)

    def recover(self):
        self.isStart = True
        self.InputLabel.config(state=DISABLED)
        self.RunButton.config(state=DISABLED)
        while self.isStart:
            # 将结果显示到文本框中
            self.quitButton.config(state=DISABLED)
            self.name = f'{self.cnt}_{datetime.now().minute}-{datetime.now().second}.png'
            self.str.set(self.name)
            self.update()
            with mouse.Listener(on_click = self.on_click) as listener:
                listener.join()

    def run(self):
        self.isStart = True
        self.root = os.path.dirname('./')
        self.currPath = str(datetime.now())[:-10].replace(' ', '_').replace(':', '_').replace('-', '_')
        self.cnt = 1

        self.InputLabel.config(state=DISABLED)
        self.RecoverButton.config(state=DISABLED)
        self.StopButton.config(state=NORMAL)

        print(f'===> 1. rootPath: {self.root} ;\t {str(datetime.now())[:-10]}')
        com_name = self.input.get()                         #获取输入的内容
        # messagebox.showinfo('Message','com_name: %s' %com_name) #显示输出
        # 请设置保存的文件夹，并将其设置为共享文件夹
        self.currPath = os.path.join(self.root, self.currPath[0:10]+ '_'+ com_name + '/')
        print(f'===> 2. currPath: {self.currPath}')
        self.str.set(self.currPath.split('\\', -1)[-1:])
        self.update()
        if not os.path.exists(self.currPath):
            os.mkdir(self.currPath)
        print(f'===> 3. Starting & Good Luck ...')

        while self.isStart:
            self.quitButton.config(state=DISABLED)
            # 将结果显示到文本框中
            self.name = f'{self.cnt}_{datetime.now().minute}-{datetime.now().second}.png'
            with mouse.Listener(on_click = self.on_click) as listener:
                listener.join()
                self.str.set(self.name)
                self.update()

IP = get_host_ip()
app = Application()
app.master.title(f"LuckyScreen(鼠标右键截图), ip=[ {IP} ]")#窗口标题
app.master.resizable(0,0) #防止用户调整尺寸
app.mainloop()#主消息循环
